#include "TestFunctions.h"
#include <iostream>

void passByReference(StringSimple& stringSimple) {
	std::cout << "String passed by reference:" << std::endl
		<< "       " << stringSimple << std::endl;
}

void passByValue(StringSimple stringSimple) {
	std::cout << "String passed by value:" << std::endl
		<< "       " << stringSimple << std::endl;
}

void lineSeparator() {
	std::cout << "==================================================================" << std::endl;
}
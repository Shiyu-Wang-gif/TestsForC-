#pragma warning(disable:4996)

#include "StringSimple.h"
#include <cstring>
#include <iostream>

// static field
int StringSimple::numberOfObjects = 0;

// constructor and destructor
StringSimple::StringSimple() {
	this->length = 0;
	this->pString = new char[1];
	pString[0] = '\0';
	StringSimple::numberOfObjects++;

	std::cout << "StringSimple() invoked" << std::endl;
}

StringSimple::StringSimple(const char* pString) {
	this->length = std::strlen(pString);
	this->pString = new char[this->length + 1];
	std::strcpy(this->pString, pString);
	StringSimple::numberOfObjects++;

	std::cout << "StringSimple(const char* pString) invoked" << std::endl;
}

StringSimple::StringSimple(const StringSimple& stringSimple) {
	this->length = stringSimple.length;
	this->pString = new char[this->length + 1];
	std::strcpy(this->pString, stringSimple.pString);
	StringSimple::numberOfObjects++;

	std::cout << "StringSimple(const StringSimple& stringSimple) invoked" << std::endl;
}

StringSimple::~StringSimple() {
	delete[] this->pString;
	StringSimple::numberOfObjects--;

	std::cout << "A StringSimple object has been destructed, "
		<< StringSimple::numberOfObjects << " left" << std::endl;
}

// method
void StringSimple::showNumberOfObjects() {
	std::cout << "There are " << StringSimple::numberOfObjects << " objects" << std::endl;
}

// operator
const StringSimple& StringSimple::operator=(const StringSimple& stringSimple) {
	std::cout << "operator=(const StringSimple& stringSimple) invoked" << std::endl;

	if (this == &stringSimple) {
		return *this;
	}

	this->length = stringSimple.length;
	delete[] this->pString;
	this->pString = new char[this->length + 1];
	std::strcpy(this->pString, stringSimple.pString);

	return *this;
}

StringSimple& StringSimple::operator=(const char* pString) {
	std::cout << "operator=(const char* pString) invoked" << std::endl;

	this->length = std::strlen(pString);
	delete[] this->pString;
	this->pString = new char[this->length + 1];
	std::strcpy(this->pString, pString);

	return *this;
}

char& StringSimple::operator[](int i) {
	return this->pString[i];
}

const char& StringSimple::operator[](int i) const {
	return this->pString[i];
}

std::ostream& operator<<(std::ostream& os, const StringSimple& stringSimple) {
	os << stringSimple.pString;
	return os;
}

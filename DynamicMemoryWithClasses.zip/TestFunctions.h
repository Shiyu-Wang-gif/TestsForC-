#pragma once

#ifndef TESTFUNCTIONS_H_
#define TESTFUNCTIONS_H_

#include "StringSimple.h"

void passByReference(StringSimple& stringSimple);
void passByValue(StringSimple stringSimple);
void lineSeparator();

#endif

#include "StringSimple.h"
#include "TestFunctions.h"
#include <iostream>

int main() {
	StringSimple stringSimple1 = StringSimple();
	std::cout << stringSimple1 << std::endl;
	StringSimple::showNumberOfObjects();
	lineSeparator();

	StringSimple stringSimple2 = StringSimple("Hello World!");
	std::cout << stringSimple2 << std::endl;
	StringSimple::showNumberOfObjects();
	lineSeparator();

	passByReference(stringSimple2);
	lineSeparator();
	passByValue(stringSimple2);
	lineSeparator();

	StringSimple stringSimple3 = stringSimple2;
	std::cout << "StringSimple stringSimple3 = stringSimple2" << std::endl
		<< "stringSimple3 = " << stringSimple3 << std::endl;
	lineSeparator();

	StringSimple stringSimple4;
	stringSimple4 = stringSimple2;
	stringSimple4 = "A string";
	std::cout << "stringSimple4 = " << stringSimple4 << std::endl;
	lineSeparator();

	stringSimple4[0] = 'a';
	std::cout << "stringSimple4 = " << stringSimple4 << std::endl;
	std::cout << "stringSimple4[2] = " << stringSimple4[2] << std::endl;
	lineSeparator();

	const StringSimple stringSimple5 = StringSimple("Another string");
	std::cout << "stringSimple5[2] = " << stringSimple5[2] << std::endl;
	lineSeparator();

	return 0;
}
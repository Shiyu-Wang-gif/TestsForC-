#pragma once

#ifndef STRINGSIMPLE_H_
#define STRINGSIMPLE_H_

#include <iostream>

class StringSimple {
private:
	char* pString;
	int length;
	static int numberOfObjects;
public:
	StringSimple();
	StringSimple(const char* pString);
	StringSimple(const StringSimple& stringSimple);
	~StringSimple();

	static void showNumberOfObjects();

	const StringSimple& operator=(const StringSimple& stringSimple);
	StringSimple& operator=(const char* pString);
	char& operator[](int i);
	const char& operator[](int i) const;
	friend std::ostream& operator<<(std::ostream& os, const StringSimple& stringSimple);

};

#endif
